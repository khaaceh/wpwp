<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Selesai Mebuat Web Gratis | KHA-WPWP</title>
    <style>
      @import url('https://fonts.googleapis.com/css2?family=Poppins&display=swap');

        body {
              font-family: 'Roboto', sans-serif;
              margin: 0;
              display: flex;
              align-items: center;
              justify-content: center;
              height: 100vh;
              color: #ffffff;
              overflow: hidden;
              background-image: url('https://i.ibb.co/pXWVztD/Screenshot-20240506-225425.jpg');
              background-size: cover;
              background-position: center;
              background: linear-gradient(135deg, #, #666666);
          }
        }
</style>
	<audio autoplay>
	<source src="argaatamvan/putar.mp3" type="audio/mp3"/>
</audio>
</head>
<body>
<body>
	 <div>
	 
<div class="panel">
    <h2>𝘽𝙚𝙧𝙝𝙖𝙨𝙞𝙡.. 
    <br>𝙒𝙚𝙗 𝙆𝙖𝙢𝙪 𝙎𝙪𝙙𝙖𝙝 𝘿𝙞𝙗𝙪𝙖𝙩 :)</h2>
    
    <div class="button-group">
        <button onclick="salinLink()">☑ 𝐒𝐚𝐥𝐢𝐧 𝐋𝐢𝐧𝐤 𝐖𝐞𝐛</button>
        <button onclick="bukaSetting()">✎ 𝐒𝐞𝐭𝐭𝐢𝐧𝐠 𝐖𝐞𝐛</button>
        </div>
       ^.^𝙹𝚊𝚗𝚐𝚊𝚗 𝙻𝚞𝚙𝚊 𝙱𝚞𝚗𝚐𝚔𝚞𝚜 𝚆𝚎𝚋 𝚗𝚢𝚊^.^
    <br>
    <div class="button-group">
        <button onclick="bungkus()">⎘ 𝐁𝐮𝐧𝐠𝐤𝐮𝐬 𝐖𝐞𝐛</button>
    </div>
</div>

<script>
    function salinLink() {
        var dummy = document.createElement("textarea");
        document.body.appendChild(dummy);
        dummy.value = window.location.origin + "/x/<?php echo $_GET['folder']; ?>";
        dummy.select();
        document.execCommand("copy");
        document.body.removeChild(dummy);
        alert("Link web kamu berhasil disalin, silahkan ^Bungkus Web^ supaya aman & gunakan generator web ini sesuai kebutuhan:)");
    }

    function bukaSetting() {
        window.location.href = "/x/<?php echo $_GET['folder']; ?>/settingsalz";
    }
    
    function bungkus() {
        window.location = 'https://bagasarya.xyz/listshortlink.php';
        }
        
</script>

</body>
</html>
